let element = {
    container: document.querySelector(".container"),
    dot : document.getElementsByClassName('dot') , 
    pause : document.querySelector('.pause') , 
    next : document.querySelector('.next') , 
    prev : document.querySelector('.prev') , 
    carousel : document.querySelector('.place .carousel'),
    i : 0 , 
  };
  
export default element;